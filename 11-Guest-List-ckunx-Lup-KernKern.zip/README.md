# Guest List

There's an array of strings that store a list of guest that are coming to a party.

Modify the `GuestList` component to display each guest as a list item in an unordered list.
import React from 'react'

export default class React extends React.Component {
  state = {
    'guests': [
      'Tony Stark',
      'Hawkeye',
      'Spider Man',
      'Bruce Wayne'
    ]
  }
  render() {
    return <React.Fragment>
    {/* your code here */}
    </React.Fragment>
  }
}
import React from 'react';
import './App.css';
import GuestList from './GuestList'

function App() {
  return (
    <div className="App">
      <GuestList/>
    </div>
  );
}

export default App;

# Transactions

Inside the `TransactionList.js` file, there is an array named `transactions` in the state that objects Each object represent one transaction.

Your task is to:

1. Display the name and the amount of each transaction in an unordered list.

2. If transactiont type is credit, display the transaction amount in green. If it is debit, display the transaction amount in red.


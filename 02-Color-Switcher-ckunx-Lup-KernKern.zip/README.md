The React app contains a component named `ColoredBox` that has a colored box and three buttons, each button for a color. 

The `ColoredBox` has a state variable named `currentColor`. If it is 1, the color of the box will be red. If it is 2, the color will be blue. If it is 3, then the color will be green. This functionality has been coded in. 

Your task is: add event handlers to the buttons and using `setState`, allow the user to change the color of the boxes.


import React from 'react';
import ColoredBox from './ColoredBox'
import './App.css';

function App() {
  
  return (
    <div className="App">
      <ColoredBox/>
    </div>
  );
}

export default App;

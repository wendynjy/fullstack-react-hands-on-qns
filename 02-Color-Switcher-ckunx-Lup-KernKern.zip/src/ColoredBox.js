import React from 'react'

class ColoredBox extends React.Component {
  state = {
    color: 1
  }

  getColor = () => {
    if (this.state.color === 1) {
      return 'red';
    }
    if (this.state.color === 2) {
      return 'blue';
    }
    if (this.state.color === 3) {
      return 'green';
    }
  }


  render() {
    return <React.Fragment>
      <div style={{
        border:'1px black solid',
        width:'50px',
        height:'50px',
        backgroundColor: this.getColor()
      }}></div>
      <button>Red</button>
      <button>Green</button>
      <button>Blue</button>
    </React.Fragment>
  }
}

export default ColoredBox;
import React from 'react'

export default class AreaForm extends React.Component {
  state = {
  
  }
  render() {
    return (
      <React.Fragment>
        <div>
          <label>Width:</label>
          <input type="text"/>
        </div>
        <div>
          <label>Height:</label>
          <input type="text"/>
        </div>
        <div>Area = </div>
      </React.Fragment>
    )
  }

  updateWidth =  (event) => {

  }

  updateHeight = (event) => {
    
  }
}
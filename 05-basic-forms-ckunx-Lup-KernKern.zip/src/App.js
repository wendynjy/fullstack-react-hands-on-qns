import React from 'react';
import './App.css';
import AreaForm from './AreaForm'

function App() {
  return (
    <div className="App">
      <AreaForm/>
    </div>
  );
}

export default App;

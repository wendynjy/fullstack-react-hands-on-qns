# Calculate Area of Rectangle

Create a form that asks the user for the width and height of a rectangle, and then display the area of the rectangle

The basic skeleton of the app has been provided in the file `AreaForm.js`. Your task is to:

1. Add in the _state_ variables
2. Setup the event handlers in the `<input type='text'>`
3. Fill in the various event handlers 
4. Display the correct answer
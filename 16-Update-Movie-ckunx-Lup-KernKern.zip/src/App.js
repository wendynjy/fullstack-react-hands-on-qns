import React from 'react';
import Movies from './Movies'
import './App.css';

function App() {
  return (
    <div className="App">
      <Movies/>      
    </div>
  );
}

export default App;

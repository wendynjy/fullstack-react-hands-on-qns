# Update movie

The `Movies` component stores an array of movies. Each movie has an `Edit` button associated with it. When the `Edit` button inside a movie display is clicked, a form will appear.

Your task is

1. Finish the `beginEditMovie` such that when the __Edit button__ for a movie is pressed, it details will appear in the form.

2. Finish the `finishEditMovie` such that the changes to the movie's details will persist in the array.